Export PDF

---
Using ireport to draw the report and java bean as the datasource

- Deploy to the tomcat and use below URL to view the sample
```
http://localhost:8080/JasperReportDemo/simpleDemo
http://localhost:8080/JasperReportDemo/subReportDemo

```