# jasper-reports-example

Example of report in PDF (Russian font), word, excel.
